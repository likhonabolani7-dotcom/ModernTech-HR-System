/**
 * VUE COMPONENTS MODULE
 * Contains all Vue 3 components for the HR System
 * Organized by functionality: Authentication, Dashboard, Employee Mgmt, Payroll, Time Off, Attendance, Performance
 */

// ============================================================================
// LOGIN/AUTHENTICATION COMPONENT
// ============================================================================
const LoginComponent = {
  template: `
    <div class="login-container">
      <div class="login-card">
        <div class="text-center mb-4">
          <i class="fas fa-building" style="font-size: 3rem; color: #0d6efd;"></i>
          <h1 class="mt-3">ModernTech South Africa</h1>
          <p class="text-muted">HR Management Portal</p>
        </div>
        
        <form @submit.prevent="handleLogin">
          <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input 
              type="text" 
              id="username" 
              v-model="credentials.username" 
              class="form-control form-control-lg"
              placeholder="Enter username"
              required
            >
            <small class="form-text text-muted">Demo: admin</small>
          </div>

          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input 
              type="password" 
              id="password" 
              v-model="credentials.password" 
              class="form-control form-control-lg"
              placeholder="Enter password"
              required
            >
            <small class="form-text text-muted">Demo: admin123</small>
          </div>

          <div v-if="errorMessage" class="alert alert-danger" role="alert">
            {{ errorMessage }}
          </div>

          <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
            <i class="fas fa-sign-in-alt"></i> Login
          </button>

          <div class="alert alert-info">
            <strong>Demo Credentials:</strong><br>
            Username: <code>admin</code><br>
            Password: <code>admin123</code>
          </div>
        </form>
      </div>
    </div>
  `,
  data() {
    return {
      credentials: {
        username: '',
        password: ''
      },
      errorMessage: ''
    };
  },
  methods: {
    handleLogin() {
      if (typeof DUMMY_DATA !== 'undefined' && 
          this.credentials.username === DUMMY_DATA.credentials.username &&
          this.credentials.password === DUMMY_DATA.credentials.password) {
        
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('currentUser', JSON.stringify({
          username: this.credentials.username,
          role: 'HR Manager',
          loginTime: new Date().toISOString()
        }));
        
        this.$emit('login-success');
      } else {
        this.errorMessage = 'Invalid username or password. Please try again.';
        setTimeout(() => { this.errorMessage = ''; }, 3000);
      }
    }
  }
};

// ============================================================================
// NAVIGATION COMPONENT
// ============================================================================
const NavigationComponent = {
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
      <div class="container-fluid">
        <a class="navbar-brand" href="#" @click.prevent="$emit('navigate', 'dashboard')">
          <i class="fas fa-building"></i> ModernTech HR
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item" v-for="tab in navigationTabs" :key="tab.id">
              <a class="nav-link" href="#" @click.prevent="$emit('navigate', tab.id)"
                :class="{ active: currentPage === tab.id, 'text-danger': tab.id === 'logout' }">
                <i :class="tab.icon"></i> {{ tab.label }}
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  `,
  props: ['currentPage'],
  data() {
    return {
      navigationTabs: [
        { id: 'dashboard', label: 'Dashboard', icon: 'fas fa-chart-line' },
        { id: 'employees', label: 'Employees', icon: 'fas fa-users' },
        { id: 'payroll', label: 'Payroll', icon: 'fas fa-money-bill-wave' },
        { id: 'timeoff', label: 'Time Off', icon: 'fas fa-calendar-alt' },
        { id: 'attendance', label: 'Attendance', icon: 'fas fa-clipboard-check' },
        { id: 'performance', label: 'Performance', icon: 'fas fa-star' },
        { id: 'logout', label: 'Logout', icon: 'fas fa-sign-out-alt' }
      ]
    };
  }
};

// ============================================================================
// DASHBOARD COMPONENT
// ============================================================================
const DashboardComponent = {
  template: `
    <div class="dashboard">
      <div class="row mb-4">
        <div class="col-md-3 mb-3">
          <div class="card card-stat">
            <div class="card-body">
              <h6 class="card-title text-muted">Total Employees</h6>
              <h2 class="card-text text-primary">{{ totalEmployees }}</h2>
              <p class="text-success"><i class="fas fa-arrow-up"></i> Active</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card card-stat">
            <div class="card-body">
              <h6 class="card-title text-muted">Pending Time Off</h6>
              <h2 class="card-text text-warning">{{ pendingTimeOff }}</h2>
              <p class="text-warning"><i class="fas fa-hourglass-half"></i> Awaiting Approval</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card card-stat">
            <div class="card-body">
              <h6 class="card-title text-muted">Monthly Payroll</h6>
              <h2 class="card-text text-success">R{{ formatCurrency(monthlyPayroll) }}</h2>
              <p class="text-info"><i class="fas fa-chart-bar"></i> All Employees</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card card-stat">
            <div class="card-body">
              <h6 class="card-title text-muted">Pending Reviews</h6>
              <h2 class="card-text text-danger">{{ pendingReviews }}</h2>
              <p class="text-danger"><i class="fas fa-tasks"></i> In Progress</p>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header bg-primary text-white">
              <h5 class="mb-0"><i class="fas fa-calendar-check"></i> Department Breakdown</h5>
            </div>
            <div class="card-body">
              <canvas id="departmentChart"></canvas>
            </div>
          </div>
        </div>

        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header bg-primary text-white">
              <h5 class="mb-0"><i class="fas fa-rand"></i> Salary Distribution</h5>
            </div>
            <div class="card-body">
              <canvas id="salaryChart"></canvas>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header bg-info text-white">
              <h5 class="mb-0"><i class="fas fa-history"></i> Recent Time Off Requests</h5>
            </div>
            <div class="card-body">
              <div v-if="recentTimeOff.length === 0" class="alert alert-info">
                No recent time off requests
              </div>
              <div v-for="request in recentTimeOff.slice(0, 5)" :key="request.id" class="mb-2 pb-2 border-bottom">
                <div class="d-flex justify-content-between">
                  <strong>{{ getEmployeeName(request.employeeId) }}</strong>
                  <span class="badge" :class="getStatusBadge(request.status)">
                    {{ request.status }}
                  </span>
                </div>
                <small class="text-muted">{{ request.type }} - {{ request.startDate }}</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header bg-success text-white">
              <h5 class="mb-0"><i class="fas fa-users"></i> Department Overview</h5>
            </div>
            <div class="card-body">
              <div v-for="dept in departmentList" :key="dept" class="mb-2">
                <div class="d-flex justify-content-between">
                  <span>{{ dept }}</span>
                  <span class="badge bg-secondary">{{ getEmployeesByDept(dept).length }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  props: ['employees', 'timeOffRequests', 'performanceReviews'],
  data() {
    return {
      departmentChart: null,
      salaryChart: null
    };
  },
  computed: {
    totalEmployees() { return this.employees ? this.employees.length : 0; },
    pendingTimeOff() { return this.timeOffRequests ? this.timeOffRequests.filter(r => r.status === 'pending').length : 0; },
    pendingReviews() { return this.performanceReviews ? this.performanceReviews.filter(r => r.status === 'pending').length : 0; },
    monthlyPayroll() {
      if (typeof PayrollCalculations !== 'undefined' && this.employees) {
        return PayrollCalculations.calculatePayrollSummary(this.employees).totalGrossSalary;
      }
      return 0;
    },
    recentTimeOff() { return this.timeOffRequests ? [...this.timeOffRequests].reverse() : []; },
    departmentList() { return this.employees ? [...new Set(this.employees.map(e => e.department))] : []; }
  },
  methods: {
    formatCurrency(value) {
      return new Intl.NumberFormat('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
    },
    getEmployeeName(id) {
      const emp = this.employees.find(e => e.id === id);
      return emp ? `${emp.firstName} ${emp.lastName}` : 'Unknown';
    },
    getStatusBadge(status) {
      const badges = { pending: 'bg-warning', approved: 'bg-success', denied: 'bg-danger' };
      return badges[status] || 'bg-secondary';
    },
    getEmployeesByDept(dept) {
      return this.employees.filter(e => e.department === dept);
    },
    initCharts() {
      // Fix: Safely clear previous global chart instances to avoid canvas conflicts
      if (this.departmentChart) { this.departmentChart.destroy(); }
      if (this.salaryChart) { this.salaryChart.destroy(); }

      this.$nextTick(() => {
        if (typeof Chart === 'undefined') return;

        const deptCtx = document.getElementById('departmentChart');
        if (deptCtx) {
          const deptData = this.departmentList.map(dept => this.getEmployeesByDept(dept).length);
          this.departmentChart = new Chart(deptCtx, {
            type: 'doughnut',
            data: {
              labels: this.departmentList,
              datasets: [{
                data: deptData,
                backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#0dcaf0', '#6f42c1']
              }]
            },
            options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'bottom' } } }
          });
        }

        const salaryCtx = document.getElementById('salaryChart');
        if (salaryCtx) {
          const salaryRanges = ['<R500k', 'R500-750k', 'R750k-1M', 'R1-1.5M', 'R1.5M+'];
          const salaryData = [
            this.employees.filter(e => e.salary < 500000).length,
            this.employees.filter(e => e.salary >= 500000 && e.salary < 750000).length,
            this.employees.filter(e => e.salary >= 750000 && e.salary < 1000000).length,
            this.employees.filter(e => e.salary >= 1000000 && e.salary < 1500000).length,
            this.employees.filter(e => e.salary >= 1500000).length
          ];
          this.salaryChart = new Chart(salaryCtx, {
            type: 'bar',
            data: {
              labels: salaryRanges,
              datasets: [{ label: 'Employees', data: salaryData, backgroundColor: '#0d6efd' }]
            },
            options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
          });
        }
      });
    }
  },
  mounted() { this.initCharts(); },
  unmounted() {
    if (this.departmentChart) { this.departmentChart.destroy(); }
    if (this.salaryChart) { this.salaryChart.destroy(); }
  }
};

// ============================================================================
// EMPLOYEE MANAGEMENT COMPONENT
// ============================================================================
const EmployeeComponent = {
  template: `
    <div class="employees-section">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-users"></i> Employee Management</h2>
        <button class="btn btn-primary" @click="showForm = true">
          <i class="fas fa-plus"></i> Add Employee
        </button>
      </div>

      <div class="row mb-3">
        <div class="col-md-6">
          <input type="text" v-model="searchTerm" class="form-control" placeholder="Search by name or email...">
        </div>
        <div class="col-md-6">
          <select v-model="filterDept" class="form-select">
            <option value="">All Departments</option>
            <option v-for="dept in departments" :key="dept" :value="dept">{{ dept }}</option>
          </select>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-hover">
          <thead class="table-light">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Position</th>
              <th>Department</th>
              <th>Salary</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="emp in filteredEmployees" :key="emp.id" class="align-middle">
              <td><strong>{{ emp.firstName }} {{ emp.lastName }}</strong></td>
              <td>{{ emp.email }}</td>
              <td>{{ emp.position }}</td>
              <td><span class="badge bg-info">{{ emp.department }}</span></td>
              <td>R{{ formatCurrency(emp.salary) }}</td>
              <td><span class="badge bg-success">{{ emp.employmentStatus || 'Active' }}</span></td>
              <td>
                <button class="btn btn-sm btn-info me-1" @click="viewEmployee(emp)"><i class="fas fa-eye"></i> View</button>
                <button class="btn btn-sm btn-warning" @click="editEmployee(emp)"><i class="fas fa-edit"></i> Edit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div v-if="selectedEmployee" class="modal d-block" style="background: rgba(0,0,0,0.5);" @click.self="selectedEmployee = null">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">{{ selectedEmployee.firstName }} {{ selectedEmployee.lastName }}</h5>
              <button type="button" class="btn-close" @click="selectedEmployee = null"></button>
            </div>
            <div class="modal-body">
              <div class="mb-2"><strong>Email:</strong> {{ selectedEmployee.email }}</div>
              <div class="mb-2"><strong>Phone:</strong> {{ selectedEmployee.phone }}</div>
              <div class="mb-2"><strong>Position:</strong> {{ selectedEmployee.position }}</div>
              <div class="mb-2"><strong>Department:</strong> {{ selectedEmployee.department }}</div>
              <div class="mb-2"><strong>Hire Date:</strong> {{ selectedEmployee.hireDate }}</div>
              <div class="mb-2"><strong>Salary:</strong> R{{ formatCurrency(selectedEmployee.salary) }}</div>
              <div class="mb-2"><strong>Manager:</strong> {{ selectedEmployee.manager || 'N/A' }}</div>
              <div class="mb-2"><strong>Office Location:</strong> {{ selectedEmployee.officeLocation }}</div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="selectedEmployee = null">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  props: ['employees'],
  data() {
    return { searchTerm: '', filterDept: '', selectedEmployee: null, showForm: false };
  },
  computed: {
    departments() { return this.employees ? [...new Set(this.employees.map(e => e.department))] : []; },
    filteredEmployees() {
      if (!this.employees) return [];
      return this.employees.filter(emp => {
        const matchSearch = !this.searchTerm || 
                           emp.firstName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
                           emp.lastName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
                           emp.email.toLowerCase().includes(this.searchTerm.toLowerCase());
        const matchDept = !this.filterDept || emp.department === this.filterDept;
        return matchSearch && matchDept;
      });
    }
  },
  methods: {
    formatCurrency(value) {
      return new Intl.NumberFormat('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
    },
    viewEmployee(emp) { this.selectedEmployee = emp; },
    editEmployee(emp) { alert('Edit functionality would be implemented in full version'); }
  }
};

// ============================================================================
// PAYROLL COMPONENT
// ============================================================================
const PayrollComponent = {
  template: `
    <div class="payroll-section">
      <h2 class="mb-4"><i class="fas fa-money-bill-wave"></i> Payroll Management</h2>

      <div class="row mb-4" v-if="summary">
        <div class="col-md-6 mb-3">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Monthly Payroll Summary</h5>
              <div class="mb-2"><span class="fw-bold">Total Gross Salary:</span><span class="float-end">R{{ formatCurrency(summary.totalGrossSalary) }}</span></div>
              <div class="mb-2"><span class="fw-bold">Total Taxes:</span><span class="float-end text-danger">R{{ formatCurrency(summary.totalTaxes) }}</span></div>
              <div class="mb-2"><span class="fw-bold">Total Deductions:</span><span class="float-end text-warning">R{{ formatCurrency(summary.totalDeductions) }}</span></div>
              <hr>
              <div class="mb-2"><span class="fw-bold">Total Net Salary:</span><span class="float-end text-success">R{{ formatCurrency(summary.totalNetSalary) }}</span></div>
            </div>
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Statistical Overview</h5>
              <div class="mb-2"><span class="fw-bold">Employee Count:</span><span class="float-end">{{ summary.employeeCount }}</span></div>
              <div class="mb-2"><span class="fw-bold">Avg. Gross Salary:</span><span class="float-end">R{{ formatCurrency(summary.averageGrossSalary) }}</span></div>
              <div class="mb-2"><span class="fw-bold">Highest Salary:</span><span class="float-end">R{{ formatCurrency(summary.highestSalary) }}</span></div>
              <div class="mb-2"><span class="fw-bold">Lowest Salary:</span><span class="float-end">R{{ formatCurrency(summary.lowestSalary) }}</span></div>
            </div>
          </div>
        </div>
      </div>

      <div class="mb-4">
        <button class="btn btn-success btn-lg" @click="generateAllPayslips">
          <i class="fas fa-file-invoice-dollar"></i> Generate All Payslips
        </button>
      </div>

      <div class="table-responsive">
        <table class="table table-hover">
          <thead class="table-light">
            <tr>
              <th>Employee</th>
              <th>Position</th>
              <th>Gross Salary</th>
              <th>Taxes</th>
              <th>Deductions</th>
              <th>Net Salary</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="payroll in payrolls" :key="payroll.employeeId">
              <td><strong>{{ payroll.firstName }} {{ payroll.lastName }}</strong></td>
              <td>{{ payroll.position }}</td>
              <td>R{{ formatCurrency(payroll.grossSalary) }}</td>
              <td class="text-danger">R{{ formatCurrency(payroll.totalTaxes) }}</td>
              <td class="text-warning">R{{ formatCurrency(payroll.totalDeductions) }}</td>
              <td class="text-success fw-bold">R{{ formatCurrency(payroll.netSalary) }}</td>
              <td>
                <button class="btn btn-sm btn-primary" @click="viewPayslip(payroll)"><i class="fas fa-download"></i> Payslip</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Payslip Detail Modal -->
      <div v-if="selectedPayslip" class="modal d-block" style="background: rgba(0,0,0,0.5);" @click.self="selectedPayslip = null">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Digital Payslip - {{ selectedPayslip.firstName }} {{ selectedPayslip.lastName }}</h5>
              <button type="button" class="btn-close" @click="selectedPayslip = null"></button>
            </div>
            <div class="modal-body">
              <div class="payslip-container">
                <div class="text-center mb-3">
                  <h4>ModernTech South Africa</h4>
                  <p class="text-muted">Monthly Payslip (ZA)</p>
                </div>
                <hr>
                <div class="row mb-3">
                  <div class="col-md-6">
                    <p><strong>Employee Name:</strong> {{ selectedPayslip.firstName }} {{ selectedPayslip.lastName }}</p>
                    <p><strong>Employee ID:</strong> {{ selectedPayslip.employeeId }}</p>
                    <p><strong>Position:</strong> {{ selectedPayslip.position }}</p>
                  </div>
                  <div class="col-md-6 text-end">
                    <p><strong>Pay Date:</strong> {{ selectedPayslip.payDate || 'N/A' }}</p>
                    <p><strong>Department:</strong> {{ selectedPayslip.department }}</p>
                    <p><strong>Payment Status:</strong> <span class="badge bg-success">{{ selectedPayslip.paymentStatus || 'Processed' }}</span></p>
                  </div>
                </div>
                <hr>
                <div class="row mb-3">
                  <div class="col-md-6">
                    <strong>Earnings</strong>
                    <div class="ms-2">
                      <p>Gross Salary: <span class="float-end">R{{ formatCurrency(selectedPayslip.grossSalary) }}</span></p>
                    </div>
                  </div>
                  <div class="col-md-6" v-if="selectedPayslip.taxes && selectedPayslip.deductions">
                    <strong>Deductions</strong>
                    <div class="ms-2">
                      <p>PAYE Tax: <span class="float-end">R{{ formatCurrency(selectedPayslip.taxes.payeTax || 0) }}</span></p>
                      <p>UIF: <span class="float-end">R{{ formatCurrency(selectedPayslip.taxes.uif || 0) }}</span></p>
                      <p>SARS Admin: <span class="float-end">R{{ formatCurrency(selectedPayslip.taxes.sarsAdmin || 0) }}</span></p>
                      <p>Medical Aid: <span class="float-end">R{{ formatCurrency(selectedPayslip.deductions.medicalAid || 0) }}</span></p>
                      <p>Pension Fund: <span class="float-end">R{{ formatCurrency(selectedPayslip.deductions.pensionFund || 0) }}</span></p>
                      <p>Group Life Insurance: <span class="float-end">R{{ formatCurrency(selectedPayslip.deductions.groupLife || 0) }}</span></p>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <strong>Total Deductions: <span class="float-end">R{{ formatCurrency(selectedPayslip.totalDeductions) }}</span></strong>
                  </div>
                  <div class="col-md-6">
                    <h5>Net Salary: <span class="float-end text-success">R{{ formatCurrency(selectedPayslip.netSalary) }}</span></h5>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success" @click="downloadPayslip"><i class="fas fa-download"></i> Download PDF</button>
              <button type="button" class="btn btn-secondary" @click="selectedPayslip = null">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  props: ['employees'],
  data() {
    return { payrolls: [], selectedPayslip: null };
  },
  computed: {
    summary() {
      if (typeof PayrollCalculations !== 'undefined' && this.employees) {
        return PayrollCalculations.calculatePayrollSummary(this.employees);
      }
      return null;
    }
  },
  methods: {
    generateAllPayslips() {
      if (typeof PayrollCalculations === 'undefined') return;
      this.payrolls = PayrollCalculations.generateMonthlyPayroll(this.employees);
      const data = JSON.parse(localStorage.getItem('hrSystemData') || '{}');
      data.payslips = this.payrolls;
      localStorage.setItem('hrSystemData', JSON.stringify(data));
      alert(`Generated ${this.payrolls.length} payslips successfully!`);
    },
    viewPayslip(payroll) { this.selectedPayslip = payroll; },
    downloadPayslip() { alert('PDF download would be implemented in full version'); },
    formatCurrency(value) {
      return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);
    }
  },
  mounted() {
    const data = JSON.parse(localStorage.getItem('hrSystemData') || '{}');
    if (data.payslips && data.payslips.length > 0) { this.payrolls = data.payslips; }
  }
};

// ============================================================================
// TIME OFF REQUEST COMPONENT
// ============================================================================
const TimeOffComponent = {
  template: `
    <div class="timeoff-section">
      <h2 class="mb-4"><i class="fas fa-calendar-alt"></i> Time Off Request Management</h2>

      <div class="row mb-3">
        <div class="col-md-3 mb-2"><div class="card"><div class="card-body"><p class="text-muted mb-0">Total Requests</p><h3>{{ allRequests.length }}</h3></div></div></div>
        <div class="col-md-3 mb-2"><div class="card"><div class="card-body"><p class="text-muted mb-0">Pending</p><h3 class="text-warning">{{ pendingCount }}</h3></div></div></div>
        <div class="col-md-3 mb-2"><div class="card"><div class="card-body"><p class="text-muted mb-0">Approved</p><h3 class="text-success">{{ approvedCount }}</h3></div></div></div>
        <div class="col-md-3 mb-2"><div class="card"><div class="card-body"><p class="text-muted mb-0">Denied</p><h3 class="text-danger">{{ deniedCount }}</h3></div></div></div>
      </div>

      <div class="table-responsive">
        <table class="table table-hover">
          <thead class="table-light">
            <tr>
              <th>Employee</th>
              <th>Type</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Days</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in allRequests" :key="request.id">
              <td><strong>{{ getEmployeeName(request.employeeId) }}</strong></td>
              <td><span class="badge" :class="getTypeColor(request.type)">{{ request.type }}</span></td>
              <td>{{ request.startDate }}</td>
              <td>{{ request.endDate }}</td>
              <td>{{ calculateDays(request.startDate, request.endDate) }}</td>
              <td>{{ request.reason }}</td>
              <td><span class="badge" :class="getStatusBadge(request.status)">{{ request.status }}</span></td>
              <td>
                <div v-if="request.status === 'pending'">
                  <button class="btn btn-sm btn-success me-1" @click="approveRequest(request)"><i class="fas fa-check"></i> Approve</button>
                  <button class="btn btn-sm btn-danger" @click="denyRequest(request)"><i class="fas fa-times"></i> Deny</button>
                </div>
                <span v-else class="text-muted">-</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  props: ['timeOffRequests', 'employees'],
  computed: {
    allRequests() { return this.timeOffRequests || []; },
    pendingCount() { return this.allRequests.filter(r => r.status === 'pending').length; },
    approvedCount() { return this.allRequests.filter(r => r.status === 'approved').length; },
    deniedCount() { return this.allRequests.filter(r => r.status === 'denied').length; }
  },
  methods: {
    getEmployeeName(id) {
      const emp = this.employees.find(e => e.id === id);
      return emp ? `${emp.firstName} ${emp.lastName}` : 'Unknown';
    },
    getTypeColor(type) {
      const colors = { 'Vacation': 'bg-info', 'Sick Leave': 'bg-danger', 'Personal Day': 'bg-warning' };
      return colors[type] || 'bg-secondary';
    },
    getStatusBadge(status) {
      const badges = { pending: 'bg-warning', approved: 'bg-success', denied: 'bg-danger' };
      return badges[status] || 'bg-secondary';
    },
    calculateDays(start, end) {
      const s = new Date(start);
      const e = new Date(end);
      return Math.ceil((e - s) / (1000 * 60 * 60 * 24)) + 1;
    },
    approveRequest(request) {
      request.status = 'approved';
      this.updateRequests();
    },
    denyRequest(request) {
      request.status = 'denied';
      this.updateRequests();
    },
    updateRequests() {
      const data = JSON.parse(localStorage.getItem('hrSystemData') || '{}');
      data.timeOffRequests = this.allRequests;
      localStorage.setItem('hrSystemData', JSON.stringify(data));
    }
  }
};

// ============================================================================
// ATTENDANCE COMPONENT
// ============================================================================
const AttendanceComponent = {
  template: `
    <div class="attendance-section">
      <h2 class="mb-4"><i class="fas fa-clipboard-check"></i> Attendance Tracking</h2>

      <div class="row mb-4">
        <div class="col-md-6 mb-3">
          <input type="month" v-model="selectedMonth" class="form-control">
        </div>
        <div class="col-md-6 mb-3">
          <select v-model="selectedEmployee" class="form-select">
            <option value="">All Employees</option>
            <option v-for="emp in employees" :key="emp.id" :value="emp.id">
              {{ emp.firstName }} {{ emp.lastName }}
            </option>
          </select>
        </div>
      </div>

      <div class="row mb-4">
        <div class="col-md-3 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Present</p><h3 class="text-success">{{ presentCount }}</h3></div></div></div>
        <div class="col-md-3 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Absent</p><h3 class="text-danger">{{ absentCount }}</h3></div></div></div>
        <div class="col-md-3 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Total Hours</p><h3 class="text-info">{{ totalHours }}</h3></div></div></div>
        <div class="col-md-3 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Attendance Rate</p><h3 class="text-primary">{{ attendanceRate }}%</h3></div></div></div>
      </div>

      <div class="table-responsive">
        <table class="table table-hover">
          <thead class="table-light">
            <tr>
              <th>Employee</th>
              <th>Date</th>
              <th>Status</th>
              <th>Hours Worked</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="record in filteredRecords" :key="record.employeeId + '-' + record.date">
              <td><strong>{{ getEmployeeName(record.employeeId) }}</strong></td>
              <td>{{ record.date }}</td>
              <td><span class="badge" :class="record.status === 'present' ? 'bg-success' : 'bg-danger'">{{ record.status }}</span></td>
              <td>{{ record.hoursWorked }} hrs</td>
              <td>
                <button class="btn btn-sm btn-info" @click="editRecord(record)"><i class="fas fa-edit"></i> Edit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  props: ['attendanceRecords', 'employees'],
  data() {
    return {
      selectedMonth: new Date().toISOString().slice(0, 7),
      selectedEmployee: ''
    };
  },
  computed: {
    filteredRecords() {
      if (!this.attendanceRecords) return [];
      return this.attendanceRecords.filter(record => {
        const dateMatch = record.date.startsWith(this.selectedMonth);
        // Fix: Safely perform empty comparison string checks before calling parseInt()
        const empMatch = !this.selectedEmployee || record.employeeId === parseInt(this.selectedEmployee, 10);
        return dateMatch && empMatch;
      });
    },
    presentCount() { return this.filteredRecords.filter(r => r.status === 'present').length; },
    absentCount() { return this.filteredRecords.filter(r => r.status === 'absent').length; },
    totalHours() { return this.filteredRecords.reduce((sum, r) => sum + (r.hoursWorked || 0), 0); },
    attendanceRate() {
      const total = this.presentCount + this.absentCount;
      if (total === 0) return 0;
      return Math.round((this.presentCount / total) * 100);
    }
  },
  methods: {
    getEmployeeName(id) {
      const emp = this.employees.find(e => e.id === id);
      return emp ? `${emp.firstName} ${emp.lastName}` : 'Unknown';
    },
    editRecord(record) { alert('Edit functionality would be implemented in full version'); }
  }
};

// ============================================================================
// PERFORMANCE REVIEWS COMPONENT
// ============================================================================
const PerformanceComponent = {
  template: `
    <div class="performance-section">
      <h2 class="mb-4"><i class="fas fa-star"></i> Performance Reviews</h2>

      <div class="row mb-4">
        <div class="col-md-4 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Total Reviews</p><h3>{{ localReviews.length }}</h3></div></div></div>
        <div class="col-md-4 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Completed</p><h3 class="text-success">{{ completedCount }}</h3></div></div></div>
        <div class="col-md-4 mb-3"><div class="card"><div class="card-body"><p class="text-muted mb-0">Pending</p><h3 class="text-warning">{{ pendingCount }}</h3></div></div></div>
      </div>

      <div class="table-responsive">
        <table class="table table-hover">
          <thead class="table-light">
            <tr>
              <th>Employee</th>
              <th>Review Period</th>
              <th>Reviewer</th>
              <th>Rating</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="review in localReviews" :key="review.id">
              <td><strong>{{ getEmployeeName(review.employeeId) }}</strong></td>
              <td>{{ review.reviewPeriod }}</td>
              <td>{{ review.reviewer }}</td>
              <td>
                <span v-if="review.rating" class="badge bg-info"><i class="fas fa-star"></i> {{ review.rating }}/5</span>
                <span v-else class="badge bg-secondary">Pending</span>
              </td>
              <td><span class="badge" :class="review.status === 'completed' ? 'bg-success' : 'bg-warning'">{{ review.status }}</span></td>
              <td>
                <button class="btn btn-sm btn-primary me-1" @click="viewReview(review)"><i class="fas fa-eye"></i> View</button>
                <button v-if="review.status === 'pending'" class="btn btn-sm btn-info" @click="editReview(review)"><i class="fas fa-edit"></i> Complete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div v-if="selectedReview" class="modal d-block" style="background: rgba(0,0,0,0.5);" @click.self="selectedReview = null">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Performance Review - {{ getEmployeeName(selectedReview.employeeId) }}</h5>
              <button type="button" class="btn-close" @click="selectedReview = null"></button>
            </div>
            <div class="modal-body">
              <div class="mb-2"><strong>Review Period:</strong> {{ selectedReview.reviewPeriod }}</div>
              <div class="mb-2"><strong>Reviewer:</strong> {{ selectedReview.reviewer }}</div>
              <div class="mb-2"><strong>Review Date:</strong> {{ selectedReview.reviewDate || 'Not completed' }}</div>
              <div class="mb-2"><strong>Rating:</strong> 
                <span v-if="selectedReview.rating">{{ selectedReview.rating }}/5.0</span>
                <span v-else class="text-muted">Pending</span>
              </div>
              <div class="mb-2"><strong>Comments:</strong><p>{{ selectedReview.comments || 'No comments yet' }}</p></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="selectedReview = null">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  props: ['performanceReviews', 'employees'],
  data() {
    return { selectedReview: null };
  },
  computed: {
    // Fix: Dynamic tracking to mirror parent props safely without direct mutation
    localReviews() { return this.performanceReviews || []; },
    completedCount() { return this.localReviews.filter(r => r.status === 'completed').length; },
    pendingCount() { return this.localReviews.filter(r => r.status === 'pending').length; }
  },
  methods: {
    getEmployeeName(id) {
      const emp = this.employees.find(e => e.id === id);
      return emp ? `${emp.firstName} ${emp.lastName}` : 'Unknown';
    },
    viewReview(review) { this.selectedReview = review; },
    editReview(review) { alert('Edit functionality would be implemented in full version'); }
  }
};
