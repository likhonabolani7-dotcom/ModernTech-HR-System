/**
 * PAYROLL CALCULATIONS MODULE
 * Contains all business logic for payroll calculations
 * Implements automated payroll processing with digital payslip generation
 * 
 * LOCALE: South Africa (ZA)
 * TAX SYSTEM: SARS PAYE (Pay As You Earn)
 */

const PayrollCalculations = {
  // South African Tax Rates and Thresholds
  TAX_RATES: {
    payeTax: 0.18,      // Average PAYE tax (varies by income bracket)
    uif: 0.01,          // Unemployment Insurance Fund - 1% (employee contribution)
    sars: 0.015         // SARS administrative percentage
  },

  // South African Deduction amounts (monthly)
  DEDUCTIONS: {
    medicalAid: 250,    // Medical aid contribution
    pensionFund: 150,   // Pension fund contribution (PRASA/similar)
    groupLife: 50       // Group life insurance
  },

  /**
   * Calculate all payroll details for an employee for a given period
   * @param {Object} employee - Employee data
   * @param {number} daysWorked - Number of days worked in the period
   * @param {number} hoursWorked - Total hours worked in the period
   * @returns {Object} Payroll calculation details
   */
  calculatePayroll(employee, daysWorked = 22, hoursWorked = 176) {
    const grossSalary = this.calculateGrossSalary(employee, daysWorked, hoursWorked);
    const taxes = this.calculateTaxes(grossSalary);
    const deductions = this.calculateDeductions();
    const totalDeductions = Object.values(taxes).reduce((a, b) => a + b, 0) + 
                           Object.values(deductions).reduce((a, b) => a + b, 0);
    const netSalary = grossSalary - totalDeductions;

    return {
      employeeId: employee.id,
      firstName: employee.firstName,
      lastName: employee.lastName,
      position: employee.position,
      department: employee.department,
      salary: employee.salary,
      daysWorked,
      hoursWorked,
      grossSalary: parseFloat(grossSalary.toFixed(2)),
      taxes: {
        payeTax: parseFloat(taxes.payeTax.toFixed(2)),
        uif: parseFloat(taxes.uif.toFixed(2)),
        sarsAdmin: parseFloat(taxes.sarsAdmin.toFixed(2))
      },
      deductions: {
        medicalAid: deductions.medicalAid,
        pensionFund: deductions.pensionFund,
        groupLife: deductions.groupLife
      },
      totalTaxes: parseFloat(Object.values(taxes).reduce((a, b) => a + b, 0).toFixed(2)),
      totalDeductions: parseFloat(Object.values(deductions).reduce((a, b) => a + b, 0).toFixed(2)),
      totalDeductionsAll: parseFloat(totalDeductions.toFixed(2)),
      netSalary: parseFloat(netSalary.toFixed(2)),
      payDate: new Date().toISOString().split('T')[0]
    };
  },

  /**
   * Calculate gross salary based on employee salary and hours/days worked
   * @param {Object} employee - Employee data
   * @param {number} daysWorked - Days worked in period
   * @param {number} hoursWorked - Hours worked in period
   * @returns {number} Gross salary
   */
  calculateGrossSalary(employee, daysWorked = 22, hoursWorked = 176) {
    // Assuming standard work year has 22 working days per month
    // or 176 working hours per month (22 days * 8 hours)
    const monthlyGross = employee.salary / 12;
    
    if (hoursWorked < 176) {
      // Calculate based on hours worked if less than standard
      return (employee.hourlyRate * hoursWorked);
    }
    
    return monthlyGross;
  },

  /**
   * Calculate tax deductions for South Africa
   * @param {number} grossSalary - Gross salary amount
   * @returns {Object} Tax breakdown
   */
  calculateTaxes(grossSalary) {
    return {
      payeTax: grossSalary * this.TAX_RATES.payeTax,
      uif: grossSalary * this.TAX_RATES.uif,
      sarsAdmin: grossSalary * this.TAX_RATES.sars
    };
  },

  /**
   * Calculate fixed deductions (South African)
   * @returns {Object} Deduction breakdown
   */
  calculateDeductions() {
    return {
      medicalAid: this.DEDUCTIONS.medicalAid,
      pensionFund: this.DEDUCTIONS.pensionFund,
      groupLife: this.DEDUCTIONS.groupLife
    };
  },

  /**
   * Generate a digital payslip for an employee
   * @param {Object} payrollData - Payroll calculation data
   * @returns {Object} Payslip object for storage/display
   */
  generatePayslip(payrollData) {
    const payslip = {
      id: `PS-${payrollData.employeeId}-${Date.now()}`,
      ...payrollData,
      generatedDate: new Date().toISOString().split('T')[0],
      paymentMethod: 'EFT Transfer',
      paymentStatus: 'Pending',
      currency: 'ZAR',
      paymentReference: `MOD-${Date.now()}`
    };
    
    return payslip;
  },

  /**
   * Calculate attendance bonus/penalty
   * If employee has perfect attendance in the period, add bonus
   * If there are absences, apply penalty
   * @param {number} hoursWorked - Total hours worked
   * @param {number} expectedHours - Expected hours (default 176 for monthly)
   * @returns {number} Bonus/penalty amount
   */
  calculateAttendanceAdjustment(hoursWorked, expectedHours = 176) {
    const attendanceRate = hoursWorked / expectedHours;
    
    if (attendanceRate === 1) {
      return 500; // Perfect attendance bonus (R500)
    } else if (attendanceRate >= 0.9) {
      return 0; // No adjustment
    } else {
      // Penalty for significant absences
      return -(expectedHours - hoursWorked) * 100; // R100 per missing hour
    }
  },

  /**
   * Generate monthly payroll report for all employees
   * @param {Array} employees - Array of employee objects
   * @returns {Array} Array of payroll data for all employees
   */
  generateMonthlyPayroll(employees) {
    return employees.map(employee => this.calculatePayroll(employee));
  },

  /**
   * Calculate total payroll costs for the company
   * @param {Array} employees - Array of employee objects
   * @returns {Object} Summary payroll statistics
   */
  calculatePayrollSummary(employees) {
    const payrolls = this.generateMonthlyPayroll(employees);
    const totalGross = payrolls.reduce((sum, p) => sum + p.grossSalary, 0);
    const totalTaxes = payrolls.reduce((sum, p) => sum + p.totalTaxes, 0);
    const totalDeductions = payrolls.reduce((sum, p) => sum + p.totalDeductions, 0);
    const totalNet = payrolls.reduce((sum, p) => sum + p.netSalary, 0);

    return {
      employeeCount: payrolls.length,
      totalGrossSalary: parseFloat(totalGross.toFixed(2)),
      totalTaxes: parseFloat(totalTaxes.toFixed(2)),
      totalDeductions: parseFloat(totalDeductions.toFixed(2)),
      totalNetSalary: parseFloat(totalNet.toFixed(2)),
      averageGrossSalary: parseFloat((totalGross / payrolls.length).toFixed(2)),
      averageNetSalary: parseFloat((totalNet / payrolls.length).toFixed(2)),
      highestSalary: Math.max(...payrolls.map(p => p.grossSalary)),
      lowestSalary: Math.min(...payrolls.map(p => p.grossSalary))
    };
  }
};
