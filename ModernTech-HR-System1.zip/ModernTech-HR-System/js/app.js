/**
 * MAIN VUE APPLICATION - ModernTech HR System
 * Initializes the Vue 3 app with all components and state management
 * Handles authentication, navigation, and data management
 */

const { createApp } = Vue;

const app = createApp({
  template: `
    <div>
      <!-- Login Screen -->
      <login-component 
        v-if="!isAuthenticated" 
        @login-success="handleLogin"
      />

      <!-- Main Application -->
      <div v-else class="app-wrapper">
        <!-- Navigation Bar -->
        <navigation-component 
          :currentPage="currentPage" 
          @navigate="navigateTo"
          @logout="handleLogout"
        />

        <!-- Main Content -->
        <div class="container-fluid px-4 py-4">
          <!-- Dashboard -->
          <dashboard-component 
            v-if="currentPage === 'dashboard'"
            :employees="employees"
            :timeOffRequests="timeOffRequests"
            :performanceReviews="performanceReviews"
            :attendanceRecords="attendanceRecords"
          />

          <!-- Employee Management -->
          <employee-component 
            v-if="currentPage === 'employees'"
            :employees="employees"
            @update-employee="updateEmployee"
            @add-employee="addEmployee"
          />

          <!-- Payroll Management -->
          <payroll-component 
            v-if="currentPage === 'payroll'"
            :employees="employees"
          />

          <!-- Time Off Requests -->
          <time-off-component 
            v-if="currentPage === 'timeoff'"
            :timeOffRequests="timeOffRequests"
            :employees="employees"
            @update-request="updateTimeOffRequest"
          />

          <!-- Attendance Tracking -->
          <attendance-component 
            v-if="currentPage === 'attendance'"
            :attendanceRecords="attendanceRecords"
            :employees="employees"
          />

          <!-- Performance Reviews -->
          <performance-component 
            v-if="currentPage === 'performance'"
            :performanceReviews="performanceReviews"
            :employees="employees"
            @update-review="updatePerformanceReview"
          />
        </div>
      </div>
    </div>
  `,
  components: {
    'login-component': LoginComponent,
    'navigation-component': NavigationComponent,
    'dashboard-component': DashboardComponent,
    'employee-component': EmployeeComponent,
    'payroll-component': PayrollComponent,
    'time-off-component': TimeOffComponent,
    'attendance-component': AttendanceComponent,
    'performance-component': PerformanceComponent
  },
  data() {
    return {
      isAuthenticated: false,
      currentPage: 'dashboard',
      employees: [],
      timeOffRequests: [],
      attendanceRecords: [],
      performanceReviews: [],
      payslips: []
    };
  },
  methods: {
    /**
     * Initialize application by loading data from localStorage or dummy data
     */
    initializeApp() {
      const stored = localStorage.getItem('hrSystemData');
      if (stored) {
        try {
          const data = JSON.parse(stored);
          this.employees = data.employees || DUMMY_DATA.employees;
          this.timeOffRequests = data.timeOffRequests || DUMMY_DATA.timeOffRequests;
          this.attendanceRecords = data.attendanceRecords || DUMMY_DATA.attendanceRecords;
          this.performanceReviews = data.performanceReviews || DUMMY_DATA.performanceReviews;
          this.payslips = data.payslips || [];
        } catch (e) {
          console.error('Error loading data from localStorage:', e);
          this.loadDummyData();
        }
      } else {
        this.loadDummyData();
      }
    },

    /**
     * Load dummy data and save to localStorage
     */
    loadDummyData() {
      this.employees = DUMMY_DATA.employees;
      this.timeOffRequests = DUMMY_DATA.timeOffRequests;
      this.attendanceRecords = DUMMY_DATA.attendanceRecords;
      this.performanceReviews = DUMMY_DATA.performanceReviews;
      this.payslips = [];
      this.saveData();
    },

    /**
     * Save all data to localStorage
     */
    saveData() {
      try {
        const data = {
          employees: this.employees,
          timeOffRequests: this.timeOffRequests,
          attendanceRecords: this.attendanceRecords,
          performanceReviews: this.performanceReviews,
          payslips: this.payslips
        };
        localStorage.setItem('hrSystemData', JSON.stringify(data));
      } catch (e) {
        console.error('Error saving data to localStorage:', e);
      }
    },

    /**
     * Handle successful login
     */
    handleLogin() {
      this.isAuthenticated = true;
      this.initializeApp();
      this.currentPage = 'dashboard';
      localStorage.setItem('isAuthenticated', 'true');
    },

    /**
     * Handle logout
     */
    handleLogout() {
      this.isAuthenticated = false;
      this.currentPage = 'dashboard';
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('currentUser');
    },

    /**
     * Navigate to a specific page
     */
    navigateTo(page) {
      if (page === 'logout') {
        this.handleLogout();
      } else {
        this.currentPage = page;
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    },

    /**
     * Update an employee
     */
    updateEmployee(updatedEmployee) {
      const index = this.employees.findIndex(e => e.id === updatedEmployee.id);
      if (index !== -1) {
        this.employees.splice(index, 1, updatedEmployee);
        this.saveData();
      }
    },

    /**
     * Add a new employee
     */
    addEmployee(newEmployee) {
      const maxId = Math.max(...this.employees.map(e => e.id), 0);
      newEmployee.id = maxId + 1;
      this.employees.push(newEmployee);
      this.saveData();
    },

    /**
     * Update a time off request
     */
    updateTimeOffRequest(updatedRequest) {
      const index = this.timeOffRequests.findIndex(r => r.id === updatedRequest.id);
      if (index !== -1) {
        this.timeOffRequests.splice(index, 1, updatedRequest);
        this.saveData();
      }
    },

    /**
     * Update a performance review
     */
    updatePerformanceReview(updatedReview) {
      const index = this.performanceReviews.findIndex(r => r.id === updatedReview.id);
      if (index !== -1) {
        this.performanceReviews.splice(index, 1, updatedReview);
        this.saveData();
      }
    }
  },
  mounted() {
    // Check if user is already authenticated
    const isAuth = localStorage.getItem('isAuthenticated') === 'true';
    if (isAuth) {
      this.isAuthenticated = true;
      this.initializeApp();
    }
  }
});

// Register global error handler
app.config.errorHandler = (err, instance, info) => {
  console.error('Vue Error:', err, info);
};

// Mount the app
app.mount('#app');
