/**
 * DUMMY DATA MODULE
 * Contains all sample employee records and initial application data
 * This simulates data that would come from a backend API
 * 
 * LOCALE: South Africa (ZA)
 * CURRENCY: South African Rand (ZAR)
 */

const DUMMY_DATA = {
  // Global Configuration for South African Localization
  config: {
    locale: 'en-ZA',
    currency: 'ZAR',
    currencySymbol: 'R',
    timezone: 'Africa/Johannesburg',
    dateFormat: 'DD/MM/YYYY',
    decimalSeparator: '.',
    thousandsSeparator: ','
  },

  // Authentication credentials for the mock system
  credentials: {
    username: 'admin',
    password: 'admin123'
  },

  // 15+ Employee Records with Complete Information
  employees: [
    {
      id: 1001,
      firstName: 'Thabo',
      lastName: 'Mthembu',
      email: 'thabo.mthembu@moderntech.co.za',
      phone: '011-555-0101',
      department: 'Software Development',
      position: 'Senior Developer',
      hireDate: '2018-03-15',
      salary: 950000,
      hourlyRate: 456.73,
      employmentStatus: 'Active',
      manager: 'Naledi Khumalo',
      officeLocation: 'Johannesburg',
      profileImage: '👨‍💼'
    },
    {
      id: 1002,
      firstName: 'Naledi',
      lastName: 'Khumalo',
      email: 'naledi.khumalo@moderntech.co.za',
      phone: '011-555-0102',
      department: 'Software Development',
      position: 'Development Manager',
      hireDate: '2016-07-22',
      salary: 1150000,
      hourlyRate: 552.88,
      employmentStatus: 'Active',
      manager: 'Mandla Nkosi',
      officeLocation: 'Johannesburg',
      profileImage: '👩‍💼'
    },
    {
      id: 1003,
      firstName: 'Mandla',
      lastName: 'Nkosi',
      email: 'mandla.nkosi@moderntech.co.za',
      phone: '011-555-0103',
      department: 'Leadership',
      position: 'CTO',
      hireDate: '2015-01-10',
      salary: 1800000,
      hourlyRate: 865.38,
      employmentStatus: 'Active',
      manager: null,
      officeLocation: 'Johannesburg',
      profileImage: '👨‍💼'
    },
    {
      id: 1004,
      firstName: 'Zola',
      lastName: 'Dlamini',
      email: 'zola.dlamini@moderntech.co.za',
      phone: '021-555-0104',
      department: 'Quality Assurance',
      position: 'QA Lead',
      hireDate: '2017-09-05',
      salary: 850000,
      hourlyRate: 408.65,
      employmentStatus: 'Active',
      manager: 'Naledi Khumalo',
      officeLocation: 'Cape Town',
      profileImage: '👩‍💼'
    },
    {
      id: 1005,
      firstName: 'Sipho',
      lastName: 'Botha',
      email: 'sipho.botha@moderntech.co.za',
      phone: '021-555-0105',
      department: 'Quality Assurance',
      position: 'QA Analyst',
      hireDate: '2019-11-18',
      salary: 720000,
      hourlyRate: 346.15,
      employmentStatus: 'Active',
      manager: 'Zola Dlamini',
      officeLocation: 'Cape Town',
      profileImage: '👨‍💼'
    },
    {
      id: 1006,
      firstName: 'Lerato',
      lastName: 'Motlanthe',
      email: 'lerato.motlanthe@moderntech.co.za',
      phone: '031-555-0106',
      department: 'Customer Support',
      position: 'Support Manager',
      hireDate: '2017-04-12',
      salary: 780000,
      hourlyRate: 375.00,
      employmentStatus: 'Active',
      manager: 'Mandla Nkosi',
      officeLocation: 'Durban',
      profileImage: '👩‍💼'
    },
    {
      id: 1007,
      firstName: 'Khaya',
      lastName: 'Ndlela',
      email: 'khaya.ndlela@moderntech.co.za',
      phone: '031-555-0107',
      department: 'Customer Support',
      position: 'Support Specialist',
      hireDate: '2020-06-08',
      salary: 550000,
      hourlyRate: 264.42,
      employmentStatus: 'Active',
      manager: 'Lerato Motlanthe',
      officeLocation: 'Durban',
      profileImage: '👨‍💼'
    },
    {
      id: 1008,
      firstName: 'Imani',
      lastName: 'De Villiers',
      email: 'imani.devilliers@moderntech.co.za',
      phone: '012-555-0108',
      department: 'Sales',
      position: 'Sales Manager',
      hireDate: '2016-10-03',
      salary: 920000,
      hourlyRate: 442.31,
      employmentStatus: 'Active',
      manager: 'Mandla Nkosi',
      officeLocation: 'Pretoria',
      profileImage: '👩‍💼'
    },
    {
      id: 1009,
      firstName: 'Sizwe',
      lastName: 'Meyer',
      email: 'sizwe.meyer@moderntech.co.za',
      phone: '012-555-0109',
      department: 'Sales',
      position: 'Sales Executive',
      hireDate: '2019-02-15',
      salary: 680000,
      hourlyRate: 326.92,
      employmentStatus: 'Active',
      manager: 'Imani De Villiers',
      officeLocation: 'Pretoria',
      profileImage: '👨‍💼'
    },
    {
      id: 1010,
      firstName: 'Nomsa',
      lastName: 'Gumede',
      email: 'nomsa.gumede@moderntech.co.za',
      phone: '011-555-0110',
      department: 'Marketing',
      position: 'Marketing Director',
      hireDate: '2014-05-20',
      salary: 1050000,
      hourlyRate: 504.81,
      employmentStatus: 'Active',
      manager: 'Mandla Nkosi',
      officeLocation: 'Johannesburg',
      profileImage: '👩‍💼'
    },
    {
      id: 1011,
      firstName: 'Themba',
      lastName: 'Zwane',
      email: 'themba.zwane@moderntech.co.za',
      phone: '011-555-0111',
      department: 'Marketing',
      position: 'Content Specialist',
      hireDate: '2020-08-10',
      salary: 620000,
      hourlyRate: 298.08,
      employmentStatus: 'Active',
      manager: 'Nomsa Gumede',
      officeLocation: 'Johannesburg',
      profileImage: '👨‍💼'
    },
    {
      id: 1012,
      firstName: 'Busiswa',
      lastName: 'Sibiya',
      email: 'busiswa.sibiya@moderntech.co.za',
      phone: '031-555-0112',
      department: 'Human Resources',
      position: 'HR Manager',
      hireDate: '2015-12-07',
      salary: 880000,
      hourlyRate: 423.08,
      employmentStatus: 'Active',
      manager: 'Mandla Nkosi',
      officeLocation: 'Durban',
      profileImage: '👩‍💼'
    },
    {
      id: 1013,
      firstName: 'Jabu',
      lastName: 'Mkhize',
      email: 'jabu.mkhize@moderntech.co.za',
      phone: '021-555-0113',
      department: 'Software Development',
      position: 'Frontend Developer',
      hireDate: '2021-01-25',
      salary: 780000,
      hourlyRate: 375.00,
      employmentStatus: 'Active',
      manager: 'Naledi Khumalo',
      officeLocation: 'Cape Town',
      profileImage: '👨‍💼'
    },
    {
      id: 1014,
      firstName: 'Precious',
      lastName: 'Mahlangu',
      email: 'precious.mahlangu@moderntech.co.za',
      phone: '012-555-0114',
      department: 'Software Development',
      position: 'Backend Developer',
      hireDate: '2020-05-18',
      salary: 820000,
      hourlyRate: 394.23,
      employmentStatus: 'Active',
      manager: 'Naledi Khumalo',
      officeLocation: 'Pretoria',
      profileImage: '👩‍💼'
    },
    {
      id: 1015,
      firstName: 'Luthando',
      lastName: 'Jacobs',
      email: 'luthando.jacobs@moderntech.co.za',
      phone: '021-555-0115',
      department: 'Quality Assurance',
      position: 'Automation Tester',
      hireDate: '2021-09-13',
      salary: 750000,
      hourlyRate: 360.58,
      employmentStatus: 'Active',
      manager: 'Zola Dlamini',
      officeLocation: 'Cape Town',
      profileImage: '👨‍💼'
    },
    {
      id: 1016,
      firstName: 'Amara',
      lastName: 'Govender',
      email: 'amara.govender@moderntech.co.za',
      phone: '031-555-0116',
      department: 'Customer Support',
      position: 'Support Specialist',
      hireDate: '2021-03-22',
      salary: 540000,
      hourlyRate: 259.62,
      employmentStatus: 'Active',
      manager: 'Lerato Motlanthe',
      officeLocation: 'Durban',
      profileImage: '👩‍💼'
    },
    {
      id: 1017,
      firstName: 'Tyron',
      lastName: 'Van Der Merwe',
      email: 'tyron.vdmerwe@moderntech.co.za',
      phone: '012-555-0117',
      department: 'Sales',
      position: 'Sales Executive',
      hireDate: '2022-01-10',
      salary: 650000,
      hourlyRate: 312.50,
      employmentStatus: 'Active',
      manager: 'Imani De Villiers',
      officeLocation: 'Pretoria',
      profileImage: '👨‍💼'
    }
  ],

  // Time Off Requests (status: pending, approved, denied)
  timeOffRequests: [
    {
      id: 'TOR001',
      employeeId: 1001,
      startDate: '2026-07-10',
      endDate: '2026-07-14',
      type: 'Annual Leave',
      status: 'pending',
      reason: 'Winter holiday',
      requestDate: '2026-06-15'
    },
    {
      id: 'TOR002',
      employeeId: 1003,
      startDate: '2026-06-28',
      endDate: '2026-06-28',
      type: 'Sick Leave',
      status: 'approved',
      reason: 'Medical appointment',
      requestDate: '2026-06-20'
    },
    {
      id: 'TOR003',
      employeeId: 1005,
      startDate: '2026-07-20',
      endDate: '2026-07-24',
      type: 'Annual Leave',
      status: 'pending',
      reason: 'Family trip',
      requestDate: '2026-06-18'
    },
    {
      id: 'TOR004',
      employeeId: 1007,
      startDate: '2026-07-04',
      endDate: '2026-07-04',
      type: 'Compassionate Leave',
      status: 'approved',
      reason: 'Family matter',
      requestDate: '2026-06-22'
    },
    {
      id: 'TOR005',
      employeeId: 1009,
      startDate: '2026-06-25',
      endDate: '2026-06-26',
      type: 'Sick Leave',
      status: 'denied',
      reason: 'Flu',
      requestDate: '2026-06-23'
    }
  ],

  // Attendance Records
  attendanceRecords: [
    { employeeId: 1001, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1001, date: '2026-06-21', status: 'present', hoursWorked: 8 },
    { employeeId: 1001, date: '2026-06-22', status: 'absent', hoursWorked: 0 },
    { employeeId: 1002, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1002, date: '2026-06-21', status: 'present', hoursWorked: 8 },
    { employeeId: 1003, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1004, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1005, date: '2026-06-20', status: 'present', hoursWorked: 7 },
    { employeeId: 1006, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1007, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1008, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1009, date: '2026-06-20', status: 'present', hoursWorked: 8 },
    { employeeId: 1010, date: '2026-06-20', status: 'present', hoursWorked: 8 }
  ],

  // Performance Reviews (stored as documents with ratings)
  performanceReviews: [
    {
      id: 'PR001',
      employeeId: 1001,
      reviewDate: '2026-03-15',
      reviewPeriod: '2025-Q4',
      rating: 4.2,
      reviewer: 'Naledi Khumalo',
      comments: 'Excellent performance, completed projects on time',
      status: 'completed'
    },
    {
      id: 'PR002',
      employeeId: 1004,
      reviewDate: '2026-03-20',
      reviewPeriod: '2025-Q4',
      rating: 3.8,
      reviewer: 'Naledi Khumalo',
      comments: 'Good work on QA testing, needs improvement in documentation',
      status: 'completed'
    },
    {
      id: 'PR003',
      employeeId: 1010,
      reviewDate: null,
      reviewPeriod: '2026-Q2',
      rating: null,
      reviewer: 'Mandla Nkosi',
      comments: '',
      status: 'pending'
    }
  ]
};

// Initialize localStorage with dummy data if not already present
function initializeLocalStorage() {
  if (!localStorage.getItem('hrSystemData')) {
    localStorage.setItem('hrSystemData', JSON.stringify({
      employees: DUMMY_DATA.employees,
      timeOffRequests: DUMMY_DATA.timeOffRequests,
      attendanceRecords: DUMMY_DATA.attendanceRecords,
      performanceReviews: DUMMY_DATA.performanceReviews,
      payslips: []
    }));
  }
}

// Call initialization on script load
initializeLocalStorage();
