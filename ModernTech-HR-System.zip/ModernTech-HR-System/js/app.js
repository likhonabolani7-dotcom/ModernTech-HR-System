/**
 * MAIN VUE APPLICATION
 * Initializes the Vue 3 app with all components and state management
 * Handles authentication, navigation, and data management
 */

const { createApp } = Vue;

const app = createApp({
  template: `
    <div>
      <!-- Login Screen -->
      <login-component 
        v-if="!isAuthenticated" 
        @login-success="handleLogin"
      />

      <!-- Main Application -->
      <div v-else>
        <!-- Navigation Bar -->
        <navigation-component 
          :currentPage="currentPage" 
          @navigate="navigateTo"
          @logout="handleLogout"
        />

        <!-- Main Content -->
        <div class="container-fluid px-4 py-4">
          <!-- Dashboard -->
          <dashboard-component 
            v-if="currentPage === 'dashboard'"
            :employees="employees"
            :timeOffRequests="timeOffRequests"
            :performanceReviews="performanceReviews"
          />

          <!-- Employee Management -->
          <employee-component 
            v-if="currentPage === 'employees'"
            :employees="employees"
          />

          <!-- Payroll Management -->
          <payroll-component 
            v-if="currentPage === 'payroll'"
            :employees="employees"
          />

          <!-- Time Off Requests -->
          <time-off-component 
            v-if="currentPage === 'timeoff'"
            :timeOffRequests="timeOffRequests"
            :employees="employees"
          />

          <!-- Attendance Tracking -->
          <attendance-component 
            v-if="currentPage === 'attendance'"
            :attendanceRecords="attendanceRecords"
            :employees="employees"
          />

          <!-- Performance Reviews -->
          <performance-component 
            v-if="currentPage === 'performance'"
            :performanceReviews="performanceReviews"
            :employees="employees"
          />
        </div>
      </div>
    </div>
  `,
  components: {
    'login-component': LoginComponent,
    'navigation-component': NavigationComponent,
    'dashboard-component': DashboardComponent,
    'employee-component': EmployeeComponent,
    'payroll-component': PayrollComponent,
    'time-off-component': TimeOffComponent,
    'attendance-component': AttendanceComponent,
    'performance-component': PerformanceComponent
  },
  data() {
    return {
      isAuthenticated: false,
      currentPage: 'dashboard',
      employees: [],
      timeOffRequests: [],
      attendanceRecords: [],
      performanceReviews: [],
      payslips: []
    };
  },
  methods: {
    /**
     * Initialize application by loading data from localStorage or dummy data
     */
    initializeApp() {
      const stored = localStorage.getItem('hrSystemData');
      if (stored) {
        const data = JSON.parse(stored);
        this.employees = data.employees || DUMMY_DATA.employees;
        this.timeOffRequests = data.timeOffRequests || DUMMY_DATA.timeOffRequests;
        this.attendanceRecords = data.attendanceRecords || DUMMY_DATA.attendanceRecords;
        this.performanceReviews = data.performanceReviews || DUMMY_DATA.performanceReviews;
        this.payslips = data.payslips || [];
      } else {
        // Initialize with dummy data
        this.employees = DUMMY_DATA.employees;
        this.timeOffRequests = DUMMY_DATA.timeOffRequests;
        this.attendanceRecords = DUMMY_DATA.attendanceRecords;
        this.performanceReviews = DUMMY_DATA.performanceReviews;
        this.payslips = [];
        this.saveData();
      }
    },

    /**
     * Save all data to localStorage
     */
    saveData() {
      const data = {
        employees: this.employees,
        timeOffRequests: this.timeOffRequests,
        attendanceRecords: this.attendanceRecords,
        performanceReviews: this.performanceReviews,
        payslips: this.payslips
      };
      localStorage.setItem('hrSystemData', JSON.stringify(data));
    },

    /**
     * Handle successful login
     */
    handleLogin() {
      this.isAuthenticated = true;
      this.initializeApp();
      this.currentPage = 'dashboard';
    },

    /**
     * Handle logout
     */
    handleLogout() {
      this.isAuthenticated = false;
      this.currentPage = 'dashboard';
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('currentUser');
    },

    /**
     * Navigate to a specific page
     */
    navigateTo(page) {
      if (page === 'logout') {
        this.handleLogout();
      } else {
        this.currentPage = page;
        // Smooth scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  },
  mounted() {
    // Check if user is already authenticated
    const isAuth = localStorage.getItem('isAuthenticated') === 'true';
    if (isAuth) {
      this.isAuthenticated = true;
      this.initializeApp();
    }
  }
});

// Register global error handler
app.config.errorHandler = (err, instance, info) => {
  console.error('Vue Error:', err, info);
};

// Mount the app
app.mount('#app');
